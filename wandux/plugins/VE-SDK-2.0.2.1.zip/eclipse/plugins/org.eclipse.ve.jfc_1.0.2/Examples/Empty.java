/**
 *  Use this skelaton to start with an empty Composition
 */
  
class Empty {


}