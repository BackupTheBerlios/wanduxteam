/**
 * This has a superclass that doesn't exist
 */
public class ExtendsNonExistantClass extends Frog {

}

