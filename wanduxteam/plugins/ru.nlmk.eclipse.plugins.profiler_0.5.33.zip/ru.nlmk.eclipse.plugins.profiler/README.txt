Eclipse Profiler Plugin
Version 0.5.30
http://eclipsecolorer.sourceforge.net

Copyright (c) 2003 Konstantin Scheglov, scheglov_ke@nlmk.ru
All Rights Reserved
Licensed under the CPL License version 1.0
===================

This is an Eclipse Java IDE plugin providing Java Profiling 
tools. It allows the Java developer to tune up the performance of their 
Java programs all within the comfort of the Eclipse IDE.
 
Current version has more or less finished CPU profiling and early version of
heap profiling. I am sure, that lot more features can be added, so feel free
to contact me.

Limitations
-----------
  Profiler has compiled native library for Win32 and Linux using gcc 3.2. If you have
Linux system with older gcc or libraries, you will need build native part yourself. 
I also tested it with gcc 2.95.3.
  Plugin tested with Sun SDK 1.4.1_02-b06 and Eclipse 2.1-Release.
  I know, that it does NOT work with IBM JDK 1.3.1, i.e. you will have
problems with this profiler and WSAD 5.0. Well, it already has profiler. ;-)


Installation
------------
- Shutdown Eclipse.
- Unzip the contents of the zip file into the plugins directory of your 
  Eclipse directory.  
- Copy ProfilerDLL.dll from root plugin folder into bin folder of your JRE installation.
- Restart Eclipse.
- Open "Profiler" perspective.
- Create profiler launch configuration.
- Launch it.
- Enjoy. ;-)

[+] Feature added.
[-] Bug fixed.
[*] Change.




30 Nov 2004 - Version 0.5.33
--------------------------
[*] Fix for 3.1 compatibility.



13 Nov 2003 - Version 0.5.30
--------------------------
[*] Fix for 2.1.2 compatibility.


6 Nov 2003 - Version 0.5.29
--------------------------
[*] Compiled and tested with Eclipse Build id: 200311040800.
[*] Added advanced profiler tab in Runtime Workbench profiling.


19 Jul 2003 - Version 0.5.28
--------------------------
[*] BCEL moved to another package because it conflicts with BCEL from JBoss.
[-] Fixed bug with package list for filters in Runtime Workbench profiling.


22 Jul 2003 - Version 0.5.27
--------------------------
[*] Several bugs fixed, tested with WebLogic 8.1 and resin-ee-2.1.10.


16 Jun 2003 - Version 0.5.25
--------------------------
[-] Bug with LDC/LDC_W in BCEL fixed. I hope, that this is reason, why
    JVM throws "VerifyError: Illegal constant pool index".
[+] Now you can use doubleclick in Packages/Classes/Methods views to
    open method in editor. Context menu was not very convinient way.
[+] "Live" thread call graph. Now it refreshes automatically, as any other
    profiler view. "Refresh" button removed.
[+] New filters for thread call graph. You can set, that you want to
    see control flows with at least 1% of total time, or 2%, 3%, 5%, 10%.
    This allows remove most of not interesting details like methods,
    which were called only once, or don't use much time.
[+] "Pause CPU profiling on method leave" option in launch configuration
    dialog. When it is on, profiler will stop gathering statistics and
    resume when control flow will enter in this method again. This allows
    you profile only part of application, without parts, which do other
    things, like preparing data for interesting part.
[-] Fixed crash in ProfilerDLL during heap profiling. Does anybody knows
    why OptimizeIt 2 times faster when does heap profiling? It seems, that
    most slow part is getting allocation trace, and it is in JVM. I don't
    know, how to make it faster. :-(



3 Jun 2003 - Version 0.5.24
--------------------------
[-] "An unrecoverable stack overflow has occurred" bug fixed.



27 May 2003 - Version 0.5.23
--------------------------
[+] Profiler tested with Eclipse on Linux (local profiling).
    Several bugs fixed.



22 May 2003 - Version 0.5.22
--------------------------
[-] In previous version I've started statistics sender thread in static
    section of Trace class. And on some computers JVM throws error:
    "Failed to load Main Class:". Fixed.



19 May 2003 - Version 0.5.21
--------------------------
[+] Option "Instrument final methods" added to "Profiler" tab.
    This allows you exclude instrumentation of final methods (
    or methods in final classes) and reduce in this case overhead.
[*] Options in launch configuration splitted on two pages - generic
    and advanced settings.
[+] Option "Start CPU profiling on method execution" added to launch
    configuration. When you have application with massive startup process
    and don't want to press stop/start, and know, what method will be
    executed after startup, you can select class and method, from which
    profiling should be started.
[+] Export of 'Inverted thread call tree' to HTML added.
[-] When project uses sources folders, plugin does not shows packages
    from them, i.e. you see only packages from attached JAR's, but
    not yours.
[*] Profiler will allocate memory for heap profiling directly in
    native code, so I hope, that ArrayIndexOutOfBoundsException will be
    not generated.



12 May 2003 - Version 0.5.20
--------------------------
[+] Button "Save statistics" added to "Threads" view. It allows you
    save current statistics in project (in folder "profiles"). Later
    you will able to open them using doubleclick on file. Name of
    file constructed from name of launch configuration plus date/time
    when save pressed plus extention ".profile". This allows you to
    analyze statistics later without incurring the performance penalty of
    profiling when you really want to review the stats.
[+] If you profile applications with JDK 1.4+, then when you stop profiling
    using "Stop profiling" button on "Threads" view, profiler will avoid
    most overhead, so in result application run only 30% slower (!), then
    without profiling at all. Same is true if you start profiling with
    disabled auto start. I think, that with such low slowdown it is possible
    to start applications almost always with profiling and activate it
    only when you want to gather statistics. After this you can stop profiling
    and your application will work fast again. This is especially usefull for
    such long runned applications as Tomcat and JBoss.
      Limitation for Java 1.4 is related with method
    Throwable.getStackTrace(), without this method I can not restore call
    stack and all call stack base statistics (thread call stack, call graph)
    will be wrong. So, I decided to disable this feature with JDK lower
    than 1.4.
[+] Export thread call graph to GIF/PNG/JPG added.
[+] Export thread call tree in HTML JavaScript tree.


6 May 2003 - Version 0.5.19
--------------------------
[+] Option "Auto start CPU profiling" added to launch configuration.
    So, if you want to profile only part of your application, you can
    disable auto start, run application under profiler and press "Start"
    on "Threads" view in needed moment.
[*] Small change in internal sending thread - if it can not bind socket,
    it still will run application. This situation happens, when you start
    Tomcat and then use shutdown script to stop it. So, now you will able
    to do this.


28 Apr 2003 - Version 0.5.18
--------------------------
[+] "Instrument method" option added to "Profiler" tab of launch
    configuration. You can specify, what methods should be instrumented,
    and what not. There are fairly much methods, which only pass control
    to other methods, or does simple check of some condition. Such simple
    and short methods usually can by inlined by JVM and almost don't use
    CPU. However if profiler instrument them, they become bigger, more
    complex and statistics can be affected. Now you can select, instrument
    all methods (for example to look on full thread call graph), or
    exclude method not bigger, than 50, 100, etc bytes, which does not
    contain back braches (i.e. does not have cycles).
[+] "Profile system classes" option added. As you may be noticed, profiler
    shows calls not for all methods and classes, in particilar for core
    java classes - String, StringBuffer, etc. Problem is that JVM loads
    these classes before profiler can set class load hook. When you turn
    this option on, profiler will add enter/leave code in each place of
    other methods, where methods from system classes (java.lang.*,
    java.io.*) are called. This option most usefull for testing profiler,
    or writing small examples, for profilers are work. I don't think, that
    it can be usefull in real profiling.
[-] Version 0.5.17 was compiled in Java 1.4 compatibility mode, so plugin
    could not be loaded when Eclipse started with JDK 1.3. Now I compile it
    with JDK 1.3 again.


21 Apr 2003 - Version 0.5.17
--------------------------
[+] Preferences page in Window|Preferences created.
    Currently it contains only settings for colors of
    changed and unchanged items in views.
[+] New view "Reversed thread call tree" added. It shows
    call tree starting fron leaves, so if one leaf uses
    much time, you will able to see, who calls it and how
    much time this takes. Then you can decide - optimize
    leaf method or try to remove/replace it in parent method.


15 Apr 2003 - Version 0.5.16
--------------------------
[+] Mark instances in "Instances" view.
    After this in column "+" difference between marked size and current
    size of instances will be displayed. This allows to see how memory
    usage has been changed after some action.
[*] Monitor profiling is in progress, but does not work yet.
[-] Bug fixed in "Thread call graph" - when method called recursivally,
    total time and hit count has been summarized. However only first time
    total time should be used.


1 Apr 2003 - Version 0.5.15
--------------------------
[+] Scale support in call graph view.
    You can scale to minimum, to name, to name and direct time percent
    or to any value using Scale widget.


25 Mar 2003 - Version 0.5.14
--------------------------
[+] Linux support (remote only).
    You will need build libProfilerDLL.so from sources and copy it
    to jre/libi386. File "m" in profiler_linux.tgz is example of compilation
    script. Change it as needed for you OS.
    See also profile_cpu/profile_heap for examples of start line for cpu and
    heap profiling and r_cpu/r_heap as example how to use them.


18 Mar 2003 - Version 0.5.13
--------------------------
[+] Added sampling as new timing method. In reallity this is
    completely different implementation of CPU profiling. With
    this method bytecode of classes not changed, but profiler
    suspends threads, makes call stack snapshot and resumes execution
    of thread. So, overhead is not so much as for instrumentation.
[*] Added JAVA_OPTS line for Tomcat heap profiling (see documentation).


12 Mar 2003 - Version 0.5.12
--------------------------
[+] "10 seconds object" and "1 minute objects" in Instances view allows
    you filter out temporary objects and see only long lived ones.
[+] Profiler was tested with jakarta-tomcat-4.1.12 and 
    jboss-3.0.6_tomcat-4.1.18 (both with remote launch configuration).
    See documentation for more information.
[+] Percents and size change in "Instances" view.
[*] Profiler will not instrument classes with names ended with "$Proxy",
    may be with such modification it will able to profiler JBoss. You
    can also try to add org.jboss to exclusive filter.


3 Mar 2003 - Version 0.5.11
--------------------------
[+] Profiler will wait until frontend will request statistics next time
    and allow JVM termination only after this. This allows see all
    statistics even for short programs (however I don't know, why profile
    short programs :-)).
[+] Filters in threads view.
[+] Allocation sites (view "Sites") for selected type in view "Instances"
    (don't forget close and open perspective "Profiler").
[*] ObjectOutputStream replaced by more simple class. I found strange
    behavior of it in process of debugging of allocation sites. May be
    unexpected EOF's have same reason...


28 Feb 2003 - Version 0.5.10
--------------------------
[+] Added check of DLL version in plugin and in JRE\BIN.
[*] Trace class now prints exceptions, may be this will help to
    find EOFException in model.


26 Feb 2003 - Version 0.5.9
--------------------------
[-] Fixed crash for Java 1.3 and heap profiling
    (don't forget update ProfilerDLL in jre\bin).
[-] Fixed bug with NullPointerException for closed project.


25 Feb 2003 - Version 0.5.8
--------------------------
[-] Fixed crash if -XrunProfilerDLL used without arguments.
[*] Message "Press refresh button" on call graph view added.


17 Feb 2003 - Version 0.5.7
--------------------------
[+] Applet profiling support.
[+] Runtime workbench profiling support.
[+] Basic heap profiling (only instances).
[+] Reverse sorting (by clicking on the column heading again).
[+] Find places in thread call tree, with selected method.


10 Feb 2003 - Version 0.5.6
--------------------------
[+] Draw2D based call graph.
    Display methods and calls between them with tooltips,
    full or selected parts (callers and callees).
    See screenshots on site or in documentation.


04 Feb 2003 - Version 0.5.5
--------------------------
[-] Instrumentation filter should use runtime packages, not
    project packages. Fixed.
[+] Inclusive exclusive package filters.
    Now you can noy only specify what packages should be
    excluded from instrumentation, but also what packages
    should be included. Usefull, if you want to profile only
    your own classes.
[+] Total time column in packages/classes/methods views.
[+] Instrumentation time column (how much time used for
    instrumentation of class).
[+] Now you can right click on a package/class and add it to either the 
    Profiler view filters OR the profiler launch configuration 
    instrumentation filter. (either inclusive or exclusive 
    capability as well).
[+] Simple export to HTML from packages/classes/methods and thread tree
    views.


28 Jan 2003 - Version 0.5.4
--------------------------
[-] Profiler does not work, if Eclipse installed in path
    with spaces, for example "C:\Program Files\Eclipse".
    Fixed.
[+] Legend added in heap viewer.
[+] New column Time/Inv. shows average time use by one method invocation.
[-] Empty package/class/method removed.
[*] "Open method in editor" removed for <clinit>.
[+] Inclusive name pattern filter in "Profiler filters".
[+] User defined named patterns in "Profiler filters".


24 Jan 2003 - Version 0.5.3
--------------------------
[+] Refresh rate can be set on "Profiler" tab in launch configuration.
[+] Timing method can be set on "Profiler" tab in launch configuration.
    See documentation or home page of SourceForge for details.
[+] Linux native part.
    Only remote profiling tested, with profiled program on Linux server
    and Eclipse with profiler on W2k.
    However may be it will also work inside of Eclipse plugin on Linux.
    To start programm on Linux use something like following line:
    java -XrunProfilerDLL -mx32000k -classpath .:log4j.jar -Xbootclasspath/a:jakarta-regexp.jar:commons-lang.jar:bcel.jar:profiler.jar -D__PROFILER_PACKAGE_FILTER=com.sun.:sun. -D__PROFILER_USE_PACKAGE_FILTER=1 test7
    You will need to place file libProfilerDLL.so  in LD_LIBRARY_PATH path.
[+] Profiler launch configuration can be used in debug mode.
[+] Button "Clear" in "Threads" view clears all statistics.
[*] Disable/Enable state of buttons in "Threads" view update.
[+] Buttons Pause/Resume threads in "Threads" view. You can now pause and
    resume execution, inluding remote profiling case.
[-] Profiler crashes if you specify a different classpath on the classpath tab.
    Now it will add needed jar's to bootclasspath instead of adding
    them directly in VM arguments.


22 Jan 2003 - Version 0.5.2
--------------------------
- ID's for launch configuration changes, you will need to recreate
  all profiler launch configuration.
- Remote profiling support (new launch configuration - "Remote Profiler").
- Default values in launch configuration.


21 Jan 2003 - Version 0.5.1
--------------------------
- Temporary fix for max method count (increased to 100000).
- Source code added.
- Filtering java.* and javax.* by default.
- Active filtering by default.
